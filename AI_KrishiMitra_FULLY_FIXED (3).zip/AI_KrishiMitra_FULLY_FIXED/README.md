# AI KrishiMitra — Fully Fixed Prototype

Run:
```
python -m pip install -r requirements.txt
python -m uvicorn app:app --reload
```
Open http://127.0.0.1:8000

Fixes in this build:
- AI Assistant always renders object/error responses safely; generic agriculture fallback works.
- Crop Recommendation renders each recommendation field.
- Soil Health works without login for easier demo/testing.
- Smart Irrigation works without login.
- Crop Doctor accepts image without login and provides a clearly-labelled lightweight visual screening result. It is not a trained disease-diagnosis model.
- Login sessions are saved in SQLite, so restarting Uvicorn does not invalidate the saved token.
- Protected APIs accept the frontend Bearer token correctly (fixes 422 errors in AI Assistant and My Farm).
- Old service workers are unregistered and assets are cache-busted to avoid stale JavaScript.
- GPS and manual location search remain available.

For production: connect a validated plant-vision model and authoritative live market data; use real OTP authentication and production session management.
