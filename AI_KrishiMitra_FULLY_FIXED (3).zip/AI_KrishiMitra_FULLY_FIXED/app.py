from fastapi import FastAPI, HTTPException, UploadFile, File, Depends, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import sqlite3, secrets, hashlib, time, os, json, base64, re

app = FastAPI(title="AI KrishiMitra API")

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    iterations = 310000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iterations, salt_b64, digest_b64 = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(digest_b64.encode())
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return secrets.compare_digest(actual, expected)
    except Exception:
        return False
DB = "krishimitra.db"
SESSIONS = {}

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, email TEXT UNIQUE,
        password TEXT, phone TEXT UNIQUE, state TEXT, district TEXT, language TEXT DEFAULT 'English'
    )""")
    # Upgrade older prototype databases without deleting existing accounts.
    cols = {row[1] for row in con.execute("PRAGMA table_info(users)").fetchall()}
    if "phone" not in cols:
        con.execute("ALTER TABLE users ADD COLUMN phone TEXT")
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone ON users(phone)")
    if "email" in cols:
        # Existing installations keep their email/password accounts.
        pass
    con.execute("""CREATE TABLE IF NOT EXISTS farms(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        crop TEXT, acres REAL, location TEXT, stage INTEGER DEFAULT 40,
        soil TEXT, planting_date TEXT
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS sessions(
        token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL
    )""")
    con.commit(); con.close()

init_db()

class Auth(BaseModel):
    name: str = ""
    email: str = ""
    password: str = ""
    phone: str = ""
    state: str = ""
    district: str = ""
    language: str = "English"

class Chat(BaseModel):
    message: str
    language: str = "English"

class CropRequest(BaseModel):
    soil: str
    season: str
    water: str
    acres: float = 1
    state: str = ""

class SoilRequest(BaseModel):
    ph: float
    nitrogen: str
    phosphorus: str
    potassium: str
    moisture: float
    soil_type: str

class IrrigationRequest(BaseModel):
    crop: str
    stage: str
    moisture: float
    rain_probability: float

class FarmRequest(BaseModel):
    crop: str
    acres: float
    location: str
    stage: int
    soil: str
    planting_date: str = ""

def token_for(uid):
    t = secrets.token_urlsafe(32)
    SESSIONS[t] = uid
    con=db(); con.execute("INSERT OR REPLACE INTO sessions(token,user_id,created_at) VALUES(?,?,?)", (t, uid, int(time.time()))) ; con.commit(); con.close()
    return t

def token_from_request(token: str = "", authorization: str = ""):
    if token:
        return token
    if authorization.lower().startswith("bearer "):
        return authorization.split(" ",1)[1].strip()
    return ""

def user_from_token(token):
    if not token:
        raise HTTPException(401, "Please login")
    uid = SESSIONS.get(token)
    if uid:
        return uid
    con=db(); row=con.execute("SELECT user_id FROM sessions WHERE token=?", (token,)).fetchone(); con.close()
    if not row:
        raise HTTPException(401, "Please login again")
    SESSIONS[token]=row["user_id"]
    return row["user_id"]

def simple_ai(msg, language):
    m = (msg or "").lower().strip()
    # Prototype assistant: deterministic agriculture guidance; safe fallback for arbitrary questions.
    if any(x in m for x in ["hello", "hi", "namaste", "नमस्ते"]):
        return "Namaste! I am AI KrishiMitra. Ask me about crops, soil, irrigation, weather, pests, diseases or farming practices."
    if any(x in m for x in ["yellow", "पीला", "peela", "pila", "chlorosis"]):
        return "Yellow leaves can be linked to nutrient stress, excess water, low moisture or pests. Check the underside of leaves, root-zone moisture and your latest soil test. For a visual check, upload a clear leaf photo in Crop Doctor."
    if any(x in m for x in ["pest", "insect", "कीट", "aphid", "caterpillar"]):
        return "Check leaves for holes, curling, sticky residue or insects. Remove badly affected leaves where practical, monitor the crop closely and use only crop- and pest-appropriate products according to the label and local agricultural advice."
    if any(x in m for x in ["disease", "fungus", "fungal", "spot", "rust", "mildew", "बीमारी"]):
        return "Common warning signs include spreading spots, white powdery growth, rust-colored pustules, wilting or unusual curling. Upload a clear leaf photo in Crop Doctor for a screening result, and confirm with a local agriculture expert before treatment."
    if any(x in m for x in ["irrigat", "पानी", "paani", "water", "watering"]):
        return "Decide irrigation using crop stage, root-zone soil moisture and recent or expected rainfall together. Avoid routine watering when the soil is already wet or substantial rain is expected."
    if any(x in m for x in ["crop", "फसल", "fasal", "grow", "sow", "plant"]):
        return "I can help compare crops using soil type, season, water availability and land size. Open Crop Recommendation and enter those values for a simple ranked shortlist."
    if any(x in m for x in ["weather", "मौसम", "mausam", "rain", "बारिश", "forecast"]):
        return "Use the Weather section to set your village or city. The dashboard then shows current temperature, humidity, wind and rainfall probability for the selected location."
    if any(x in m for x in ["soil", "मिट्टी", "mitti", "ph", "nitrogen", "phosphorus", "potassium"]):
        return "Use Soil Health to enter pH, nitrogen, phosphorus, potassium and moisture. The tool gives a general interpretation; fertilizer decisions should use a current soil test and crop-specific local guidance."
    if any(x in m for x in ["market", "mandi", "price", "भाव", "rate"]):
        return "Open Mandi Price Dashboard to view the prototype market panel. Its current values are demo data, so a production system should connect an authoritative live mandi source."
    return "I can help with crop selection, weather, soil, irrigation, pests and crop-health symptoms. Tell me your crop and the problem you are seeing, for example: 'My wheat leaves are turning yellow.'"

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.post("/api/signup")
def signup(a: Auth):
    if not a.name.strip(): raise HTTPException(400, "Name is required")
    email = a.email.strip().lower()
    if "@" not in email: raise HTTPException(400, "Please enter a valid email address")
    if len(a.password) < 8: raise HTTPException(400, "Password must be at least 8 characters")
    con=db()
    try:
        cur=con.execute("INSERT INTO users(name,email,password,state,district,language) VALUES(?,?,?,?,?,?)",
                        (a.name.strip(),email,hash_password(a.password),a.state.strip(),a.district.strip(),a.language))
        con.commit(); uid=cur.lastrowid
    except sqlite3.IntegrityError:
        con.close(); raise HTTPException(409,"Email already registered")
    con.close()
    return {"token": token_for(uid), "user": {"id":uid,"name":a.name,"email":a.email,"state":a.state,"district":a.district,"language":a.language}}

@app.post("/api/login")
def login(a: Auth):
    email = a.email.strip().lower()
    if not email or not a.password:
        raise HTTPException(400,"Please enter email and password, or use mobile login.")
    con=db(); u=con.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone(); con.close()
    if not u or not u["password"] or not verify_password(a.password,u["password"]):
        raise HTTPException(401,"Invalid email or password")
    return {"token": token_for(u["id"]), "user": dict(u) | {"password": None}}

@app.post("/api/phone-login")
def phone_login(a: Auth):
    # Prototype-friendly mobile login: 10-digit Indian mobile number, no OTP required.
    digits = re.sub(r"\D", "", a.phone or "")
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    if len(digits) != 10 or digits[0] not in "6789":
        raise HTTPException(400,"Enter a valid 10-digit Indian mobile number.")
    con=db()
    u=con.execute("SELECT * FROM users WHERE phone=?",(digits,)).fetchone()
    if not u:
        name=(a.name or "Farmer").strip() or "Farmer"
        email=f"{digits}@mobile.krishimitra.local"
        placeholder=hash_password(secrets.token_urlsafe(24))
        cur=con.execute("INSERT INTO users(name,email,password,phone,state,district,language) VALUES(?,?,?,?,?,?,?)",
                        (name,email,placeholder,digits,(a.state or "").strip(),(a.district or "").strip(),a.language or "English"))
        con.commit(); uid=cur.lastrowid
        u=con.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
        message="Mobile number registered and logged in."
    else:
        uid=u["id"]; message="Welcome back! Logged in with your mobile number."
        # Update profile name/location details when supplied.
        if (a.name or a.state or a.district or a.language):
            con.execute("UPDATE users SET name=?, state=?, district=?, language=? WHERE id=?",
                        ((a.name or u["name"]).strip() or "Farmer", (a.state or u["state"] or "").strip(),
                         (a.district or u["district"] or "").strip(), a.language or u["language"] or "English", uid))
            con.commit(); u=con.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    con.close()
    return {"token": token_for(uid), "user": dict(u) | {"password": None}, "message": message}

@app.get("/api/me")
def me(token: str = "", authorization: str = Header(default="")):
    uid=user_from_token(token_from_request(token, authorization)); con=db(); u=con.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone(); con.close()
    if not u: raise HTTPException(404,"User not found")
    return dict(u) | {"password":None}

@app.post("/api/chat")
def chat(c: Chat, token: str = "", authorization: str = Header(default="")):
    user_from_token(token_from_request(token, authorization))
    return {"answer": simple_ai(c.message,c.language), "timestamp": int(time.time())}


@app.get("/api/geocode")
def geocode(city: str):
    """Convert a village/city/district name to coordinates when browser GPS is unavailable."""
    import urllib.request, urllib.parse
    city = city.strip()
    if not city:
        raise HTTPException(400, "Please enter a city, village or district.")
    q = urllib.parse.urlencode({"name": city, "count": 1, "language": "en", "format": "json"})
    try:
        with urllib.request.urlopen("https://geocoding-api.open-meteo.com/v1/search?" + q, timeout=8) as r:
            data = json.loads(r.read())
        results = data.get("results") or []
        if not results:
            raise HTTPException(404, "Location not found. Try a nearby city or district.")
        x = results[0]
        return {
            "name": x.get("name", city),
            "latitude": x["latitude"],
            "longitude": x["longitude"],
            "country": x.get("country", ""),
            "admin1": x.get("admin1", "")
        }
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(503, "Location search is temporarily unavailable. You can still use the demo features.")

@app.get("/api/reverse-geocode")
def reverse_geocode(lat: float, lon: float):
    """Turn GPS coordinates into a readable city/state label."""
    import urllib.request, urllib.parse
    params=urllib.parse.urlencode({"lat":lat,"lon":lon,"format":"json","zoom":10})
    req=urllib.request.Request("https://nominatim.openstreetmap.org/reverse?"+params, headers={"User-Agent":"AI-KrishiMitra/1.0 demo"})
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            data=json.loads(r.read())
        addr=data.get("address",{})
        name=addr.get("city") or addr.get("town") or addr.get("village") or addr.get("municipality") or addr.get("county") or "Current location"
        admin1=addr.get("state") or addr.get("state_district") or ""
        return {"name":name,"admin1":admin1,"latitude":lat,"longitude":lon}
    except Exception:
        return {"name":"Current location","admin1":"","latitude":lat,"longitude":lon}

@app.get("/api/weather")
def weather(lat: float, lon: float):
    # Open-Meteo is used without an API key.
    import urllib.request, urllib.parse
    q=urllib.parse.urlencode({"latitude":lat,"longitude":lon,"current":"temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code","daily":"temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code","timezone":"auto"})
    try:
        with urllib.request.urlopen("https://api.open-meteo.com/v1/forecast?"+q, timeout=8) as r:
            return json.loads(r.read())
    except Exception:
        return {"demo":True,"current":{"temperature_2m":31,"relative_humidity_2m":62,"precipitation":0,"wind_speed_10m":12,"weather_code":2},
                "daily":{"time":["Today","Tomorrow","Day 3"],"temperature_2m_max":[32,30,31],"temperature_2m_min":[24,23,24],"precipitation_probability_max":[20,65,30]}}

@app.post("/api/crop-recommend")
def crop_recommend(c: CropRequest):
    # Public demo endpoint: crop recommendation does not require login.
    # Transparent rule-based prototype fallback, suitable until a crop ML model is connected.
    scores = {
        "Rice": (c.season.lower()=="kharif")*2 + (c.water.lower()=="high")*2 + (c.soil.lower() in ["clay","loamy"]),
        "Maize": (c.season.lower() in ["kharif","rabi"])*2 + (c.water.lower() in ["medium","high"]) + (c.soil.lower() in ["loamy","sandy loam"]),
        "Wheat": (c.season.lower()=="rabi")*3 + (c.water.lower() in ["medium","high"]) * 2 + (c.soil.lower() in ["loamy","clay"]),
        "Mustard": (c.season.lower()=="rabi")*3 + (c.water.lower()=="low")*2 + (c.soil.lower() in ["loamy","sandy"]),
        "Soybean": (c.season.lower()=="kharif")*2 + (c.water.lower()=="medium") + (c.soil.lower() in ["loamy","sandy loam"])*2
    }
    ranked=sorted(scores.items(),key=lambda x:x[1],reverse=True)
    info={"Rice":("120–150 days","High"),"Maize":("80–110 days","Medium"),"Wheat":("120–150 days","Medium"),"Mustard":("110–140 days","Low"),"Soybean":("90–120 days","Medium")}
    return {"recommendations":[{"crop":x[0],"score":x[1],"duration":info[x[0]][0],"water":info[x[0]][1],"risk":"Check local disease and weather conditions."} for x in ranked[:3]]}

@app.post("/api/soil")
def soil(s: SoilRequest):
    notes=[]
    if s.ph < 5.5: notes.append("Soil is acidic; consider a soil-test-based amendment plan.")
    elif s.ph > 8: notes.append("Soil is alkaline; confirm with a soil test before corrective action.")
    else: notes.append("pH is within a commonly suitable range for many crops.")
    notes.append(f"Nitrogen: {s.nitrogen}; Phosphorus: {s.phosphorus}; Potassium: {s.potassium}.")
    notes.append("Use crop-specific recommendations and current soil-test results for fertilizer decisions.")
    return {"summary":notes}

@app.post("/api/irrigation")
def irrigation(i: IrrigationRequest):
    if i.rain_probability >= 60: rec="Rain probability is high. Check the root-zone soil before irrigating and avoid unnecessary watering."
    elif i.moisture < 30: rec="Soil moisture is low. Check the root zone and crop stage; irrigation may be needed."
    else: rec="Soil moisture is not very low. Monitor the crop and weather before deciding on irrigation."
    return {"recommendation":rec}

@app.post("/api/farm")
def farm(f: FarmRequest, token: str = "", authorization: str = Header(default="")):
    uid=user_from_token(token_from_request(token, authorization)); con=db()
    con.execute("DELETE FROM farms WHERE user_id=?",(uid,))
    con.execute("INSERT INTO farms(user_id,crop,acres,location,stage,soil,planting_date) VALUES(?,?,?,?,?,?,?)",
                (uid,f.crop,f.acres,f.location,f.stage,f.soil,f.planting_date))
    con.commit(); row=con.execute("SELECT * FROM farms WHERE user_id=?",(uid,)).fetchone(); con.close()
    return dict(row)

@app.get("/api/farm")
def getfarm(token: str = "", authorization: str = Header(default="")):
    uid=user_from_token(token_from_request(token, authorization)); con=db(); row=con.execute("SELECT * FROM farms WHERE user_id=?",(uid,)).fetchone(); con.close()
    return dict(row) if row else None

@app.get("/api/market")
def market(crop: str="Wheat", state: str="Haryana"):
    # Clearly marked prototype/demo dataset.
    return {"demo":True,"updated":"Prototype demo data","unit":"₹/quintal",
            "crop":crop,"state":state,
            "markets":[{"name":"Mandi A","price":2350},{"name":"Mandi B","price":2410},{"name":"Mandi C","price":2390}]}

@app.post("/api/disease")
async def disease(file: UploadFile=File(...)):
    data=await file.read()
    if len(data)>8*1024*1024: raise HTTPException(413,"Image too large")
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400,"Please upload an image file.")
    # Lightweight visual screening so the prototype produces a useful result without requiring a paid AI API.
    # It estimates visible green/yellow/brown coverage; it is NOT a disease diagnosis.
    issue="Visual screening: mostly green leaf"
    message="The uploaded image looks predominantly green. No obvious stress pattern was detected by this simple screen."
    next_steps=["Keep monitoring the crop and check new leaves over the next few days", "Check soil moisture and recent weather", "Use a clear close-up image if symptoms become visible"]
    try:
        from PIL import Image
        from io import BytesIO
        img=Image.open(BytesIO(data)).convert("RGB").resize((160,160))
        pix=list(img.getdata())
        green=yellow=brown=0
        for r,g,b in pix:
            if g>r*1.08 and g>b*1.08 and g>65:
                green+=1
            if r>100 and g>85 and b<100 and r>g*0.9:
                yellow+=1
            if r>70 and g<100 and r>b*1.15 and g<b*1.2:
                brown+=1
        total=max(1,len(pix))
        yg=yellow/total; br=brown/total; gr=green/total
        if br>0.10:
            issue="Visible brown/dark spotting or damaged areas"
            message="The image contains a noticeable amount of brown or dark leaf area. This can occur with leaf spots, damage or stress, but the screen cannot identify the exact cause."
            next_steps=["Check whether spots are spreading to new leaves", "Inspect both sides of the leaf for insects or fungal growth", "Avoid unnecessary treatment until the cause is confirmed"]
        elif yg>0.18 and gr<0.65:
            issue="Visible yellowing / chlorosis pattern"
            message="The image contains noticeable yellow areas. Possible causes include nutrient stress, water stress or natural leaf ageing; confirm using crop stage and soil information."
            next_steps=["Check root-zone moisture", "Review the latest soil test for nutrient status", "Compare with newer leaves and nearby plants"]
        elif gr<0.45:
            issue="Leaf color looks mixed / image needs a clearer sample"
            message="The image contains mixed colors or background, so this screen is not confident about the leaf condition."
            next_steps=["Upload one clear leaf filling most of the frame", "Use natural light and avoid heavy shadows", "Take a second image of the front and back of the leaf"]
    except Exception:
        pass
    return {"demo":True,"issue":issue,"confidence":None,"message":message,"next_steps":next_steps}

@app.get("/api/schemes")
def schemes():
    return {"items":[
        {"name":"PM-KISAN","description":"Income support program for eligible farmer families. Verify current eligibility and application status on the official government portal.","link":"https://pmkisan.gov.in/"},
        {"name":"Pradhan Mantri Fasal Bima Yojana","description":"Crop insurance scheme. Check notified crops, areas, dates and current rules before applying.","link":"https://pmfby.gov.in/"},
        {"name":"Soil Health Card","description":"Government soil testing and soil health information service.","link":"https://soilhealth.dac.gov.in/"}
    ]}

app.mount("/static", StaticFiles(directory="static"), name="static")
