@echo off
title AI KrishiMitra
echo.
echo ==========================================
echo        AI KrishiMitra - Starting...
echo ==========================================
echo.
if not exist .venv (
  echo Creating Python virtual environment...
  python -m venv .venv
)
call .venv\Scripts\activate
echo Installing required packages...
python -m pip install -r requirements.txt
echo.
echo Website is starting...
echo Open http://127.0.0.1:8000 in Chrome.
echo Keep this window open while using the website.
echo.
python -m uvicorn app:app --host 127.0.0.1 --port 8000
pause
